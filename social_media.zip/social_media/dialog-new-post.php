<?php
    $query = "SELECT * FROM categories";
    $handler = $conn->prepare($query);
    $handler->execute();
    $result = $handler->fetchAll(PDO::FETCH_OBJ);


    if (isset($_POST['category']) && isset($_POST['content']) && strlen($_POST['content']) >= 1) {
        $query = "INSERT INTO `userspost` (`user_id`, `post_content`, `post_date`, `post_category`) VALUES (:user_id, :post_content, :post_date, :post_category)";
        $handler = $conn->prepare($query);
        $handler -> execute([
            ":user_id" => $_SESSION['login_id'],
            ":post_content" => $_POST['content'],
            ":post_date" => date('Y-m-d H:i:s'),
            ":post_category" => $_POST['category']
        ]);
        header('Location: index.php');
        exit();
    }
?>

<dialog class="new-post" id="new_post">
        <span class="make-a-post">Make A New Post</span><br>
        <form method="post">
            <div class="cate-selector">
                <label>Select A Category:</label>
                <select id="category" name="category">
                    <option value="default">Choose a Category</option>
                    <hr>
                    <?php foreach ($result as $category){
                        echo "<option value='$category->cat_name'>$category->cat_name</option>";
                    // <option value="Misc">Miscellaneous</option>
                    }
                    ?>
                </select>
            </div><br>
                <div class="posting-content">
                    <label class="writeapost">Write Your Post! (550 Characters) </label>
                    <textarea name="content" id="content" rows="12" placeholder="Post"></textarea>
                </div>
            <div class="buttondiv">
                <button type="button" id="closeModalbtn" formmethod="dialog" class="make-a-post-submit">Close</button>
                <button type="submit" value="posted" class="make-a-post-submit" id="submitpost">Post</button>
            </div>
        </form>
</dialog>
<script>
    const category = document.getElementById('category');
    const submitButton = document.getElementById('submitpost');
    submitButton.disabled = true;
    category.addEventListener('change', () => {
        if (category.value === 'default') {
        submitButton.disabled = true;
        } else {
        submitButton.disabled = false;
        }
    });
</script>