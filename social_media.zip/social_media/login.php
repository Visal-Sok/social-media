<?php

include("connect.php");


// cookie password

// if (isset ($_COOKIE['userlogin'])) {

// }else{

// }

// if (isset ($_COOKIE['userpass'])) {

// }else{

// }

// session section

if (isset($_POST['email']) && isset ($_POST['password'])) {
    unset($_SESSION['registered']);
    $email = $_POST['email'];
    $pass = $_POST['password'];
    
    $query = "SELECT user_id, user_name, user_role, preferred_theme, user_status FROM `userpass` WHERE `user_name` LIKE :email AND `user_password` LIKE :pass;";
    
    $handler = $conn->prepare($query);
            $handler->execute([
                ":email" => $email,
                ":pass" => hash('sha256', $pass)
            ]);
    $result = $handler->fetchAll(PDO::FETCH_OBJ);
            // echo "<pre>" . print_r($result, 1) . "</pre>";
            // echo $helloworld;
    if (count($result) == 1) {
        if ($result[0]->user_status == 1) {
            $_SESSION['login_id'] = $result[0]->user_id;
            $_SESSION['theme'] = $result[0]->preferred_theme;
            // echo "<pre>" . var_dump($result) . "</pre>";
            $_SESSION['role'] = $result[0]->user_role;
            header('Location: index.php');
        }
    }

    
}

if ($_POST['rememberme'] = "checked" && isset($_POST['email']) && isset ($_POST['password']) && count($result) == 1) {
    $cookie_name = "userlogin";
    $cookie_value = $email;
    setcookie($cookie_name, $cookie_value, time() + (300), "/");
    $cookie_name = "userpass";
    $cookie_value = $_POST['password'];
    setcookie($cookie_name, $cookie_value, time() + (300), "/");
    $cookie_name = "userrmbme";
    $cookie_value = "checked";
    setcookie($cookie_name, $cookie_value, time() + (300), "/");
} else {

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="js&css/stylelogin.css" preload="true">
    <link rel="stylesheet" href="js&css\colorschemelogin.css" preload="true">
</head>
<body>
    <div class="backgroundgradient">
        <div class="form1">
            <form method="POST">
                <h1><center>Log In to your Nickverse Account</center></h1><br>
                <div class="errormsg">
                    <?php
                        if (isset($_POST['email']) && isset ($_POST['password'])) {
                            // echo "<pre>" . var_dump($result) . "</pre>";
                            if(count($result) == 0) {echo "<b>Incorrect Username and Password combination.</b>
                                    <style>
                                        .errormsg {
                                            color: red;
                                            font-size: 1.3rem;
                                            font-family: 'Montserrat', sans-serif;
                                        }
                                    </style>";
                            }
                            if (isset($result[0]) && $result[0]->user_status == 0) {
                                echo "<b>Your Account Has Been Disabled.</b>
                                        <style>
                                            .errormsg {
                                                color: red;
                                                font-size: 1.3rem;
                                                font-family: 'Montserrat', sans-serif;
                                            }
                                        </style>";
                            }
                        }
                        if (isset($_SESSION['registered'])) {
                            echo "Successfully Registered! Please log in.
                                        <style>
                                            .errormsg {
                                                color: green;
                                                font-size: 1.3rem;
                                                font-family: 'Montserrat', sans-serif;
                                            }
                                        </style>";
                        }
                         ?>
                </div>
                <br><br>
                <div class="inputtext">
                    <label>Username: </label>
                    <input type="text" name="email" placeholder="Username" autocomplete="off" value="<?php 
                    // if (isset ($_COOKIE['userpass'])) { echo $_COOKIE['userlogin']; } 
                    ?>"></input>
                </div></br>
                <div class="inputtext">
                    <label>Password:</label>
                    <input type="password" name="password" type="password" placeholder="Password" autocomplete="off"  value="<?php 
                    // if (isset ($_COOKIE['userpass'])) {echo $_COOKIE['userpass'];}
                    ?>"></input>
                </div><br>
                <div class="rememberme"><input type="checkbox" name="rememberme"></input><label>Remember Me</label></div>
                </br></br>
                <a href="register.php" class="loginbtn">Register</a>
                <button type="submit" class="loginbtn">Log In</button>
            </form>
        </div>
    </div>
</body>
<style>
    .loginbtn{
        text-decoration: none;
        color: white;
        background-color: var(--darkestgreen);
        width: 120px;
        right: -315px;
        padding: 24px 36px 24px 36px;
        border-radius: 15px;
    }
</style>
</html>
<?php

?>

<!--  value="if (isset ($_COOKIE['userpass'])) { echo $_COOKIE['userpass']; } ?>" -->
<!-- value="if (isset ($_COOKIE['userlogin'])) { echo $_COOKIE['userlogin']; } ?>" -->
<!--  value="if (isset ($_COOKIE['userrmbme'])) { echo $_COOKIE['userrmbme']; } ?>" -->