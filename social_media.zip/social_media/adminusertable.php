<?php


function redirect($url) {
    echo "<script>window.location.href = '{$url}';</script>";
    exit();
}


$query = "SELECT user_id, user_name, user_email, user_role, verified, user_status FROM userpass";
$handler = $conn->query($query);
$result = $handler->fetchAll(PDO::FETCH_OBJ);

if (isset($_POST['adjustvalue'])) {
    $changestatus = "UPDATE userpass SET user_status = :inputvalue WHERE user_id = :user_id";
    $handlerquery = $conn -> prepare($changestatus);
    $handlerquery -> execute([
        ":inputvalue" => $_POST['adjustvalue'],
        ":user_id" => $_POST['userid']
    ]);
    redirect($_SERVER['REQUEST_URI']);
}
if (isset($_POST['hidepost'])) {
    $changehide = "UPDATE userspost SET ishidden = :hidevalue WHERE post_id = :post_id";
    $handlerchange = $conn -> prepare($changehide);
    $handlerchange -> execute([
        ":hidevalue" => $_POST['hidepost'],
        ":post_id" => $_POST['postid']
    ]);
}
?>

<div class='maegg'>
    <div class='titleoftbl'>
        
        <?php if (!isset($_GET['useridset'])): ?>
            <span class="sttl">User's Table</span>
        <?php else: ?>
            <a href='<?php $url = $_SERVER['REQUEST_URI'];
                            $parsed_url = parse_url($url);
                            $path = $parsed_url['path'];
                            $new_url = $path;
                            echo $new_url; ?>' class='backoutbtn text-white'><b>Return</b></a>
            <span>User's Posts</span>
        <?php endif; ?>
    </div>
        <div class="usertbl">
            <table class='usertable posttbl'>
                <?php if (!isset($_GET['useridset'])): ?>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Verified</th>
                    <th>Status</th>
                    <th> </th>
                </tr>
                <!-- <tr>
                    <td data-cell="ID">1</td>
                    <td data-cell="Name">Visal</td>
                    <td data-cell="Role">Admin</td>
                    <td data-cell="Email">sokvisal02@gmail.com</td>
                    <td data-cell="Verified">Yes</td>
                    <td data-cell="Status">
                        <button type="button">Active</button>
                    </td>
                </tr> -->
                <?php foreach ($result as $user) {
                    if ($user->verified == 1) {
                        $verified =  "  <span class='material-symbols-outlined bg-success verifiedsym'>
                                            check
                                        </span>";
                    }
                    else {
                        $verified = "<span class='material-symbols-outlined bg-danger verifiedsym'>
                                        error
                                    </span>";
                    }
                    if ($user->user_status == 1) {
                        $userstatus =  "Active";
                        $inputvalue = 0;
                        $class = 'bg-success';
                    }
                    else if ($user->user_status == 0){
                        $userstatus = "Inactive";
                        $inputvalue = 1;
                        $class = 'bg-danger';
                    }
                    echo "  <tr>
                                <td data-cell='ID'>$user->user_id</td>
                                <td data-cell='Name'><b>$user->user_name</b></td>
                                <td data-cell='Role'>$user->user_role</td>
                                <td data-cell='Email'>$user->user_email</td>
                                <td data-cell='Verified'>$verified</td>
                                <td data-cell='Status'>
                                    <form method='POST'>
                                        <button type='submit' name='adjustvalue' value='$inputvalue' class='$class text-white'>$userstatus</button>
                                        <input type='hidden' name='userid' value='$user->user_id' />
                                    </form>
                                </td>
                                <td><a href='?useridset=$user->user_id' class='bg-primary text-white'>View Posts</td>
                            </tr>";
                }
                ?>
        <?php else: ?>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Time Posted</th>
                <th>Category</th>
                <th>Engagement</th>
                <th>Visibility</th>
            </tr>
            <?php
            $usergetsetid = $_GET['useridset'];
            $querygetdata = "SELECT post_id, post_content, post_date, post_category, post_engagements, ishidden 
                            FROM userspost WHERE user_id = :user_id
                            ORDER BY DATE_FORMAT(post_date, '%Y-%m-%d %H:%i:%s') DESC";
            $handlergetdata = $conn->prepare($querygetdata);
            $handlergetdata->execute([
                ":user_id" => $usergetsetid
            ]);
            $resultgetdata = $handlergetdata->fetchAll(PDO::FETCH_OBJ);
            $i = 1;
            
            foreach ($resultgetdata as $postfromuser) {
                $posthideid = $postfromuser->post_id;
                if ($postfromuser->ishidden == 0) {
                    $class = 'bg-danger';
                    $text = "Hide";
                    $hidevalue = 1;
                }
                else {
                    $class = 'bg-success';
                    $text = "Unhide";
                    $hidevalue = 0;
                }
                echo "  <tr>
                            <td data-cell='ID'>$i</td>
                            <td data-cell='Name'>$postfromuser->post_content</td>
                            <td data-cell='Role'>$postfromuser->post_date</td>
                            <td data-cell='Email'>$postfromuser->post_category</td>
                            <td data-cell='Verified'>$postfromuser->post_engagements</td>
                            <td>
                                <form method='POST'>
                                    <input type='hidden' value='$posthideid' name='postid'></input>
                                    <input type='hidden' value='$hidevalue' name='hidepost'></input>
                                    <button class='$class text-white'>$text</button>
                                </form>
                            </td>
                        </tr>";
                        $i++;

            echo   "<style>
                    .posttbl th, .posttbl td{
                        padding: 16px 30px 16px 30px !important;
                    }
                    .usertbl {
                        max-width: 90%;
                    }
                    </style>";
            }

            ?>
        <?php endif; ?>
    </table>
</div>
    <style>
        .sttl {
            top: 12px !important;
        }
        .usertbl {
            margin-top: 120px;
            height: 75%;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 15px;
            border: #0f0f0f 1px solid;
        }
        .titleoftbl{
            display: grid;
            position: absolute;
            padding: 15px 50px 20px 40px;
            width: 100%;
            height: 15%;
            flex-shrink: 0;
            text-decoration: underline;
        }
        .titleoftbl span {
            position: relative;
            justify-self: center;
            top: -35px;
            left: 0;
            font-family: 'Montserrat', sans-serif;
            color: white;
            font-size: 2.5rem;
        }
        .titleoftbl a {
            justify-self: flex-start;
            margin-left: 30px;
            padding: 12px 24px 12px 24px;
            border-radius: 6px;
            background-color: var(--darkgreen);
        }
        .usertable{
            border-collapse: collapse;
            color: black;
        }
        td button {
            background-color: var(--darkgreen);
            border: 0px;
            padding: 8px 36px 8px 36px;
            border-radius: 100vh;
        }
        td a {
            background-color: var(--darkgreen);
            border: 0px;
            padding: 8px 28px 8px 28px;
            border-radius: 100vh;
            text-decoration: none;
        }
        .usertable td, .usertable th {
            padding: 16px 36px 16px 36px;
            text-align: center;
        }
        .maegg {
            display: flex;
            position: absolute;
            top: 15%;
            left: 30%;
            width: 65%;
            height: 70%;
            background-color: rgba(255, 255, 255,0.2);
            box-shadow: 10px 15px 4px rgba(0,0,0,0.2);
            justify-content: center;
        }
        .verifiedsym {
            color: white;
            border-radius: 6px;
            padding: 2.8px;
            font-variation-settings:
            'FILL' 0,
            'wght' 700,
            'GRAD' 200,
            'opsz' 48
        }
    </style>