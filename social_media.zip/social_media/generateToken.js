// function generateToken() {
//   var characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
//   var randomString = '';
//   for (var i = 0; i < 6; i++) {
//     var randomIndex = Math.floor(Math.random() * characters.length);
//     randomString += characters.charAt(randomIndex);
//   }
//   return randomString;
// }

// function getToken() {
//     const xhr = new XMLHttpRequest();
//     xhr.open("POST", "settingsdiv.php");
//     xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//     xhr.onload = () => {
//         const response = xhr.responseText;
//         console.log(response);
//     };

//     const randomString = generateToken();
//     const params = `token=${randomString}`;
//     xhr.send(params);
// }