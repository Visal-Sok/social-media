<?php




if (!isset($_POST['postcategory']) || $_POST['postcategory'] == "All") {
    $categorysearched = "%%";
    $_SESSION['categorysearched'] = "%%";
} else {
    $categorysearched = $_POST['postcategory'];
    $_SESSION['categorysearched'] = $_POST['postcategory'];
}

$queryCate = "SELECT upass.*, post.* 
                FROM `userspost` post 
                INNER JOIN `userpass` upass 
                ON post.user_id = upass.user_id 
                WHERE post.post_category LIKE '$categorysearched'
                AND post.ishidden = 0
                ORDER BY DATE_FORMAT(post.post_date, '%Y-%m-%d %H:%i:%s') DESC
                LIMIT 2";



$handler = $conn -> prepare($queryCate);
$handler -> execute();
$result = $handler->fetchAll(PDO::FETCH_OBJ);

// $countrow = count($result);
echo "<div class='containing' id='containerdiv'>";
foreach ($result as $post) {
    $postngm = $post->post_engagements;
    $lovelypfp = $post->user_pfp;
    $post_date = date('Y-m-d || h:ia', strtotime($post->post_date));
                if (is_null($lovelypfp)) {
                    $profile = "<span class='material-symbols-outlined myicon2'>account_circle</span>";
                }else {
                    $profile = "<img src='$lovelypfp' class='profile-pic'>";
                }
    echo "<div class='posts'>
            <div class='profile-container'>
                $profile
            </div>
            <div class='post-container'>
                <div class='user-info'>
                    <span class='usersname'>$post->user_name </span> &nbsp; &nbsp;&#x2022; &nbsp;&nbsp;$post->user_role
                </div>
                <div class='content'>
                    <span class='postcat'>$post->post_category</span><br><br>
                    <span class='post_content'>$post->post_content</span>
                    <span class='post_date'>$post_date</span>
                </div>
                <div class='actions'>
                    <div class='ngminfo'>
                        <span class='material-symbols-outlined heart-icon'>
                            monitoring
                        </span> &nbsp;&nbsp;&nbsp;
                        <span class='likengm'>
                            $postngm
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <hr>";
}


?>
<style>
    .myicon2 {
        color: white !important;
        font-size: 2rem !important;
    }
</style>