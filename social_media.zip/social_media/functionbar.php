<?php
$sessionid = $_SESSION['login_id'];
$query = "SELECT user_pfp, verified FROM `userpass` WHERE `user_id` = :sessionid;";
$stmt = $conn->prepare($query);
$stmt->bindParam(':sessionid', $sessionid);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_OBJ);
if (!isset($result[0]->user_pfp)) {
    $pfpprofile = " <span class='material-symbols-outlined myicon'>
                        account_circle
                    </span>";
} else {
    $profilepath = $result[0]->user_pfp;
    if (is_null($result[0]->user_pfp)) {
        $pfpprofile = " <span class='material-symbols-outlined myicon'>
                            account_circle
                        </span>";
    }else {
        $pfpprofile = "<img src='$profilepath' class='profile-pic2'>";
    }
}
if (!isset($result[0]->verified)) {
    $amiverified = 0;
} else {
    $amiverified = $result[0]->verified;
}

// echo "<pre>" . var_dump($result) . "</pre>";
?>


<div class="functions fixed-top">
        <div class="functions-content">
            <a href="index.php" class='ancdir'>
                <span class="material-symbols-outlined myicon">
                    home
                </span>&nbsp;&nbsp;
                Home
            </a>
        </div>
        <div class="functions-content">
            <a href="my-posts.php" class='ancdir'>
                <span class="material-symbols-outlined myicon">
                    article
                </span>&nbsp;&nbsp; 
                My Posts
            </a>
        </div>
        <?php if ($_SERVER['REQUEST_URI'] == '/social_media/my-posts.php' || $amiverified == 0): ?>
        
        <?php else: ?>
            <div class="functions-content">
                <button id="showDialogbtn" class='ancdir'>
                    <span class="material-symbols-outlined myicon">
                        add_circle
                    </span>&nbsp;&nbsp; 
                    New Posts
                </button>
            </div>
        <?php endif; ?>
        <div class="functions-content">
            <a href="settings.php" class='ancdir'>
                <span class="material-symbols-outlined myicon">
                    settings
                </span>&nbsp;&nbsp; 
                Settings
            </a>
        </div>
        <div class="functions-content profile-function">
            <a href="myprofile.php" class='ancdir'>
                <?php
                echo $pfpprofile;
                ?>
                &nbsp;&nbsp; 
                My Profile
            </a>
        </div>
    </div>

<script src="js&css/dialog.js"></script>