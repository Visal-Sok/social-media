<?php

if (isset($_POST['deleteindex'])) {
    $deleteindex = $_POST['deleteindex'];
    $query = "DELETE FROM booktb WHERE book_id = :deleteindex";
}

if (isset($_POST['deleteindex']) && isset($_SESSION['hiddenvalue']) && $_SESSION['hiddenvalue'] != 0) {
    $confirmingdeletion = $_SESSION['hiddenvalue'];
    try {
        if ($conn) {
            $handler_insert = $conn->prepare($query);
            $handler_insert -> execute ([
                ":deleteindex" => $deleteindex
            ]);
            $index1 = "";
            $index2 = "";
            $index3 = "";
            $index4 = "";
            header('Location: index.php');
            $_SESSION['deletemessagesuccess'] = 1;
        }
    }catch (PDOException $e) {
        echo $e -> getMessage();
    }
}