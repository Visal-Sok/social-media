<?php 
session_start();
$host = 'localhost';
$db = 'miniwordpressproj';
$user = 'root';
$password = '';

$dsn = "mysql:host=$host;dbname=$db;";
try {
    $conn = new PDO($dsn, $user, $password);
    if ($conn) {
        // echo "Successfully connected to the $db database!";
    }
}catch (PDOException $e) {
    echo $e -> getMessage();
}

// $conn2 = mysqli_connect($host, $user, $password, $db);

// if (!$conn2) {
//     die("Connection failed: " . mysqli_connect_error());
// }


?>
