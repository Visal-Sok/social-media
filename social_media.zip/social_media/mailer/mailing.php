<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function

session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


if (isset($_GET['mail'])) {
    $verifyemail = $_GET['mail'];
}
if (isset($_GET['token'])) {
    $verifytoken = $_GET['token'];
}
if (isset($_GET['uname'])) {
    $uname = $_GET['uname'];
}

function redirect($url) {
    echo "<script>window.location.href = '{$url}';</script>";
    exit();
}

//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_OFF;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'sandbox.smtp.mailtrap.io';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = '8a72f146db24e7';                     //SMTP username
    $mail->Password   = '47c3305aca0de9';                               //SMTP password
    $mail->SMTPSecure = 'true';            //Enable implicit TLS encryption
    $mail->Port       = 2525;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('Visal@nickverse.com', 'Admin');
    $mail->addAddress("$verifyemail", "$uname");

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    // s$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Verification Message'; //
    $mail->Body    = "<div>Your Verfication Code is <b>$verifytoken</b><div>";
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
    $_SESSION['mailsent'] = 1;
    // echo 'mailsent variable has been set';
    // echo "<pre>" . var_dump($_SESSION) . "</pre>"; 
    redirect('../settings.php');
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
