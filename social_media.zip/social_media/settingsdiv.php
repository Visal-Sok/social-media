<?php

include 'js&css/colorschemes.php';


$preferred_theme = $_SESSION['theme'];

$user_id = intval($_SESSION['login_id']);

$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$randomString = '';
for ($i = 0; $i < 6; $i++) {
    $randomString .= $characters[rand(0, strlen($characters) - 1)];
}

function redirect($url) {
    echo "<script>window.location.href = '{$url}';</script>";
    exit();
}



// echo "<pre>" . var_dump($_SESSION) . "</pre>"; 

$query = "SELECT user_email, verified, user_name, token FROM userpass WHERE user_id = :userid";
$handler = $conn -> prepare($query);
$handler -> execute([
    ":userid" => $_SESSION['login_id']
]);
$result = $handler -> fetchAll(PDO::FETCH_OBJ);
if (isset($result[0]->verified)) {
    $verifiedstatus = $result[0]->verified;
}
if (isset($result[0]->user_email)) {
    $useremail = $result[0]->user_email;
}
if (isset($result[0]->user_name)) {
    $userusername1 = $result[0]->user_name;
}
if (!isset($result[0]->user_email)) {
    $useremail = $_SESSION['email'];
    $userusername1 = $_SESSION['login_id'];
}
// echo var_dump($result[0]->verified);


if (isset($_POST['askforcode']) && isset($_POST['verifyemail'])) {
    $query = "UPDATE userpass SET token = :token WHERE user_id = $user_id";
    $handler = $conn->prepare($query);
    $handler->bindParam(':user_id', $_SESSION['login_id'], PDO::PARAM_INT);
    $handler->execute([":token"=>$randomString]);
    redirect("mailer/mailing.php?mail=$useremail&token=$randomString&uname=$userusername1");
}

if (isset($_POST['verifyme'])) {
    $verifymetoken = $_POST['verifyme'];
    if ($result[0]->token == $verifymetoken) {
        $query = "UPDATE userpass SET verified = 1 WHERE user_id = $user_id";
        $handleroftokenverify = $conn->prepare($query);
        $handleroftokenverify->execute();
        unset($_SESSION['mailsent']);
        redirect("index.php");
    }
}

if (isset($_POST['theme'])) {
    $queryupdatetheme = "UPDATE userpass SET preferred_theme = :theme WHERE user_id = :userid";
    $handler = $conn -> prepare($queryupdatetheme);
    $handler -> execute([
        "theme" => $_POST['theme'],
        ":userid" => $_SESSION['login_id']
    ]);
    $_SESSION['theme'] = $_POST['theme'];
    
} else {
    $preferred_theme = $_SESSION['theme'];
}
if (!isset($_POST['theme'])) {
    $selectedtheme = $_SESSION['theme'];
} else {
    $selectedtheme = $_POST['theme'];
}




?>






<div class="settings-container">
    <?php 
        // echo "<pre>" . var_dump($_SESSION) . "</pre>"; 
    ?>
    <form class="form" method="POST" class='optionselect'>
        <div class="themes">
            <label>Themes: </label>
            <select class="form-control" name='theme' onchange="this.form.submit()">
                <option disabled>Choose a theme</option>
                <hr>
                <option value="1" <?php if (isset($selectedtheme) && $selectedtheme == 1) echo "selected"?>>Cool & Fresh (Default)</option>
                <option value="2" <?php if (isset($selectedtheme) && $selectedtheme == 2) echo "selected"?>>Natural & Earthy</option>
                <option value="3" <?php if (isset($selectedtheme) && $selectedtheme == 3) echo "selected"?>>Stylish & Sophisticated</option>
                <option value="4" <?php if (isset($selectedtheme) && $selectedtheme == 4) echo "selected"?>>Contempory & Bold</option>
                <option value="5" <?php if (isset($selectedtheme) && $selectedtheme == 5) echo "selected"?>>Striking and Simple</option>
                <option value="6" <?php if (isset($selectedtheme) && $selectedtheme == 6) echo "selected"?>>Artsy and Creative</option>
            </select>
        </div>
        <?php if (isset($verifiedstatus) && $verifiedstatus == 0 || !isset($verifiedstatus)): ?>
        <div class='noverified'>
            <span>
                <span class="material-symbols-outlined symbol">
                    warning
                </span>&nbsp;&nbsp;&nbsp;
                <b><u>You Have Not Verified Your Account Yet!</u>&nbsp;&nbsp; <u>Please Verify Your Account As Soon As Possible!</u></b><br><br>
                As your security and privacy is our priority, Your access is limited until your account is verified
                <br><br><br>
                <?php if (!isset($_SESSION['mailsent']) && !isset($_POST['askforcode']) && !isset($_POST['verifyemail'])): ?>
                    <form method="POST">
                        <input type="hidden" name='verifyemail' value='<?php echo $useremail;?>'></input>
                        <button type="submit" class="askforcode" value='<?php echo $randomString; ?>' id='askforcode' name='askforcode'>
                            Get Code
                        </button>
                    </form>
                <?php elseif (isset($_SESSION['mailsent'])): ?>
                    <form method="POST">
                        <input type="text" class='verifybox' name="verifyme" placeholder="Verification Code"></input>&nbsp;&nbsp;&nbsp;
                        <button type='submit' class="askforcode">Verify</button>
                        <?php if (isset($_POST['verifyme']) && $result[0]->token != $verifymetoken) echo "Incorrect Verification Code! Please Check Your Email."?>
                    </form>
                <?php endif; ?>
            </span>
        </div>
        <?php endif; ?>
        <button type="button" onclick="refresh()" class="refreshbtn logoutbtn bg-success">Apply</button>
        <button class="logoutbtn bg-danger">
            <form action="logout.php" method="post">
                <input type="submit" name="logout" value="Log Out" class="dropdown-item">
            </form>
        </button>
    </form>
</div>

<style>
    .verifybox {
        padding: 10px 30px 10px 30px;
        font-size: 1.8rem;
    }
    .askforcode {
        background-color: var(--deepgreen);
        padding: 18px 50px 18px 50px;
        border-radius: 100vh;
        border: 0px solid;
    }
    .symbol {
        color: red;
        font-size: 2.1rem !important;
    }
    .noverified {
        display: flex;
        position: absolute;
        flex-shrink: 0;
        width: 80%;
        height: 20%;
        top: 225px;
    }
    .refreshbtn{
        right: 200px !important;
    }
    .form-control {
        margin-left: 40px !important;
    }
    .logoutbtn{
        width: 140px !important;
        height: 65px !important;
        position: absolute;
        bottom: 30px;
        right: 30px;
        border: 0px solid;
        background-color: var(--deepgreen);
        color: white;
        border-radius: 100vw;
    }
    /* .optionselect {
        display: flex;
        padding-top: 50px;
    } */
    label {
        font-size: 2.2rem;
    }
    .themes {
        display: flex;
        position: relative;
        justify-content: space-between;
        color: white;
        width: 40vw;
        padding-left: 2.25rem !important;
        margin: 0px;
        height: 70px;
        align-items: center;
        flex-shrink: 0;
        margin-top: 50px;
    }
    .settings-container {
        margin-top: 4vh;
        height: 80vh;
        box-shadow: 10px 10px 5px rgba(0,0,0,0.1);
        width: 60vw;
        left: 20%;
        display: flex;
        flex-shrink: 0;
        position: relative;
        justify-content: flex-start;
        padding-left: 180px;
        font-family: 'Montserrat', sans-serif;
        background-color: rgba(15,15,15,.25);
    }
</style>
<script>
    function refresh() {
        location.reload();
    }
</script>
<!-- <script src='generateToken.js'></script> -->