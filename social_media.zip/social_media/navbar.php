<?php 

$query = "SELECT * FROM categories";
$handler = $conn->prepare($query);
$handler->execute();
$result = $handler->fetchAll(PDO::FETCH_OBJ);

?>


<nav class="navbar sticky-top navbar-expand-lg px-4 py-4">
        <div class="container-fluid">
            <a class="navbar-brand px-4" href="index.php">NickVerse</a>
            <ul class="navbar-nav">
                <li class="nav-item dropdown cate1" style="top: -5px;position: relative">
                    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Categories
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <form method="POST">
                            <button type="submit" name="postcategory" value="All" class="dropdown-item">All</button>
                            <hr>
                            <?php foreach ($result as $category){
                                echo "<button type='submit' name='postcategory' value='$category->cat_name' class='dropdown-item'>$category->cat_name</button>";
                            }
                            ?>
                        </form>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-4" href="index.php">Homepage</a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link px-4" href="index.php">Friends</a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link px-4" href="my-posts.php">My Posts</a>
                </li>
                <li class="nav-item dropdown" style="top: -5px;position: relative">
                    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        My Profile
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <?php if (isset ($_SESSION['role']) && $_SESSION['role'] == 'Admin') : ?>
                            <a class="dropdown-item bg-primary text-white" href="admindashboard.php">Server Side</a>
                        <hr>
                        <?php endif; ?>
                        <a class="dropdown-item" href="my-posts.php">My Posts</a>
                        <a class="dropdown-item" href="settings.php">Settings</a>
                        <form action="logout.php" method="post" style="padding-top: 0px !important;">
                            <input type="submit" name="logout" value="Logout" class="dropdown-item bg-danger text-white">
                        </form>
                    </div>
                </li>
            </ul>
        </div>
</nav>

<!-- <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle px-3 mx-5" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        My Profile
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="index.php">My Posts</a></li>
                        <li><a class="dropdown-item" href="index.php">Settings</a></li>
                        <li><a class="dropdown-item" href="index.php">Log Out</a></li>
                    </ul>
                </div> -->