<?php

include 'connect.php';
// echo "<pre>" . var_dump($_SESSION) . "</pre>";
if (!isset($_SESSION['login_id'])) {
    header('Location: login.php');
}
// $queryclothes = "SELECT * FROM products";
// $handler = $conn->prepare($queryclothes);
// $res =  $handler->fetchAll(PDO::FETCH_OBJ);

// echo "<pre>" . var_dump($res) . "</pre>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'links.php'; ?>
    <title>Personal Blog</title>
    <link rel="stylesheet" href="js&css/modalstyle.css" preload="true">
    <?php include 'js&css/colorschemes.php'; ?>
</head>
<body>
    <?php   
        include 'navbar.php';
        include 'settingsdiv.php';
    ?>
</body>
</html>
