<?php

$query = "  SELECT * FROM pinnedposts pp
            INNER JOIN sponsor ss
            ON ss.sponsor_id = pp.sponsor_id";
$handler = $conn->prepare($query);
$handler->execute();
$result = $handler->fetchAll(PDO::FETCH_OBJ);



?>

<div class="advertisements fixed-top">
    <?php
        foreach ($result as $pinnedpost){
            if ($pinnedpost->issponsored == 1){
                $sponsoredornot = "Sponsored";
            }else {
                $sponsoredornot = "Pinned";
            }
            if (is_null($pinnedpost->sponsor_pfp)) {
                $sponsorpfp = " <span class='material-symbols-outlined adverticon'>
                                    account_circle
                                </span>";
            }else {
                $sponsorpfp = "<img src='images/sponsors/$pinnedpost->sponsor_pfp' class='profile-pic2'>";
            }
            echo "<a class='advert-post' href='$pinnedpost->link'>
            <div class='advertiser-details'>
                <div class='advertpic'>
                $sponsorpfp
                </div>
                <div class='advertisement-details'>
                    <div class='advertname'>
                        <span>$pinnedpost->sponsor_name</span>
                    </div>
                    <div class='issponsored'>
                        $sponsoredornot
                    </div>
                </div>
            </div>
            <div class='advertise-content'>
                <img src='images/pinned/$pinnedpost->pinned_img' class='advert-pic'>
            </div>
        </a>";
        }
    ?>
</div>