<?php
// session_start();

if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 0;
}
$theme = $_SESSION['theme'];

// echo $theme;

if ($theme == 0) {
    echo " <style>
    :root{
        --darkestgreen: #05386B;
        --darkgreen: #379683;
        --deepgreen: #5CDB95;
        --lightgreen: #8EE4AF;
        --greenishwhite: #EDF5E1;
    }
</style>";
}else if ($theme == 1) {
    echo " <style>
    :root{
        --darkestgreen: #05386B;
        --darkgreen: #379683;
        --deepgreen: #5CDB95;
        --lightgreen: #8EE4AF;
        --greenishwhite: #EDF5E1;
    }
</style>";
} else if ($theme == 2) {
    echo " <style>
    :root{
        --darkestgreen: #8d8741;
        --darkgreen: #659dbd;
        --deepgreen: #daad86;
        --lightgreen: #bc986a;
        --greenishwhite: #fbeec1;
    }
</style>";
} else if ($theme == 3) {
    echo " <style>
    :root{
        --darkestgreen: #5d5c61;
        --darkgreen: #379683;
        --deepgreen: #7395ae;
        --lightgreen: #557a95;
        --greenishwhite: #b1a296;
    }
</style>";
} else if ($theme == 4) {
    echo " <style>
    :root{
        --darkestgreen: #1a1a1d;
        --darkgreen: #4e4e50;
        --deepgreen: #6f2232;
        --lightgreen: #950740;
        --greenishwhite: #c3073f;
    }
</style>";
} else if ($theme == 5) {
    echo " <style>
    :root{
        --darkestgreen: #0b0c10;
        --darkgreen: #1f2833;
        --deepgreen: #a9aaab;
        --lightgreen: #66fcf1;
        --greenishwhite: #45a29e;
    }
</style>";
} else if ($theme == 6) {
    echo " <style>
    :root{
        --darkestgreen: #d79922;
        --darkgreen: #efe2ba;
        --deepgreen: #4B5054;
        --lightgreen: #4056a1;
        --greenishwhite: #c5cbe3;
    }
    .post_content{
        color: #0f0f0f !important;
    }
    .usersname{
        color: #0f0f0f !important;
    }
    .postcat{
        color: #0f0f0f !important;
    }
    .likengm {
        color: #0f0f0f !important;
    }.heart-icon {
        color: #0f0f0f !important;
    }
</style>";
}
    
?>