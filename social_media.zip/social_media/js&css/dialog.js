
let showdialogbtn = document.getElementById('showDialogbtn');
let closemodalbtn = document.getElementById('closeModalbtn');
showDialogbtn.addEventListener('click', function(e) {
    new_post.showModal();
});
closemodalbtn.addEventListener('click', function(e) {
    new_post.close();
});
// const dialog = document.getElementById('new_post');
// dialog.classList.add('show'); // To slide the dialog down
// dialog.classList.remove('show'); // To slide the dialog up
new_post.addEventListener("click", e => {
    const dialogDimensions = new_post.getBoundingClientRect()
    if (
      e.clientX < dialogDimensions.left ||
      e.clientX > dialogDimensions.right ||
      e.clientY < dialogDimensions.top ||
      e.clientY > dialogDimensions.bottom
    ) {
        new_post.close()
    }
  })