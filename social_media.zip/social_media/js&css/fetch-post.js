var offset = 0;

// Attach a scroll event listener to the window
window.addEventListener('scroll', function() {
    // Check if the user has scrolled to the bottom of the page
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
        // Send an AJAX request to fetch the next set of posts
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'fetch-posts.php');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                // Parse the JSON response into a JavaScript object
                var posts = JSON.parse(xhr.responseText);
                
                // Render the new posts on the page
                var postContainer = document.querySelector('.containing');
                for (var i = 0; i < posts.length; i++) {
                    var post = posts[i];
                    var postngm = post.post_engagements;
                    var lovelypfp = post.user_pfp ? post.user_pfp : null;
                    var post_date = new Date(post.post_date).toLocaleString();
                    var profile = lovelypfp ? "<img src='" + lovelypfp + "' class='profile-pic'>" : "<span class='material-symbols-outlined myicon2'>account_circle</span>";
                    
                    var postHTML = "<div class='posts'>" +
                        "<div class='profile-container'>" + profile + "</div>" +
                        "<div class='post-container'>" +
                            "<div class='user-info'>" +
                                "<span class='usersname'>" + post.user_name + "</span>&nbsp;&nbsp;&#x2022;&nbsp;&nbsp;<span class='user-role'>" + post.user_role + "</span>" +
                            "</div>" +
                            "<div class='content'>" +
                                "<span class='postcat'>" + post.post_category + "</span><br><br>" +
                                "<span class='post_content'>" + post.post_content + "</span>" +
                                "<span class='post_date'>" + post_date + "</span>" +
                            "</div>" +
                            "<div class='actions'>" +
                                "<form method='POST'>" +
                                    "<button type='button' name='liked' class='likebtn px-3 py-0'>" +
                                        "<span class='material-symbols-outlined heart-icon'>favorite</span>&nbsp;" +
                                        "<span class='likengm'>" + postngm + "</span>" +
                                    "</button>" +
                                "</form>" +
                            "</div>" +
                        "</div>" +
                    "</div>" +
                    "<hr>";
                    
                    // Append the new post to the container
                    postContainer.innerHTML += postHTML;
                }
                
                // Update the offset to retrieve the next set of posts
                offset += 10;
            } else {
                console.log('Request failed.  Returned status of ' + xhr.status);
            }
        };
        
        // Send the AJAX request with the current offset or page number
        xhr.send('offset=' + offset);
    }
});