let offset = 2;
let isLoading = false;

const timeout = 1100;
let lastRequestTime = 0;

window.addEventListener('scroll', () => {
  const scrollPosition = window.scrollY;

  if (scrollPosition > document.body.scrollHeight - window.innerHeight - 100) {
    const currentTime = new Date().getTime();
    if (!isLoading && currentTime - lastRequestTime >= timeout) {
      isLoading = true;
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "lazyscroll.php");
      xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhr.onload = () => {
        const postList = document.getElementById("containerdiv");
        postList.insertAdjacentHTML("beforeend", xhr.responseText);
        offset += 2;
        isLoading = false;
        lastRequestTime = new Date().getTime();
      };

      const params = `offset=${offset}`;
      xhr.send(params);
    }
  }
});