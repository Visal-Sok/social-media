<?php

include 'connect.php';
// echo "<pre>" . var_dump($_SESSION) . "</pre>";
if (!isset($_SESSION['login_id'])) {
    header('Location: login.php');
}
// $queryclothes = "SELECT * FROM products";
// $handler = $conn->prepare($queryclothes);
// $res =  $handler->fetchAll(PDO::FETCH_OBJ);

// echo "<pre>" . var_dump($res) . "</pre>";
// if (!isset($_SESSION['theme'])){
//     $_SESSION['theme'] = 1;
// }
if (isset($_POST['hiddenvalue'])) {
    unset($_POST['hiddenvalue']);
}



// echo "<pre>" . var_dump($_SESSION) . "</pre>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'js&css/colorschemes.php'; ?>
    <?php include 'links.php'; ?>
    <title>Personal Blog</title>
    <link rel="stylesheet" href="js&css/modalstyle.css" preload="true">
</head>
<body>
    <?php 
    include 'dialog-new-post.php';
    include 'navbar.php';
    include 'functionbar.php';
    include 'posts.php';
    include 'advertbar.php';
    ?>
    <script src='lazyscroll.js'></script>
</body>
</html>
