<?php

include 'connect.php';
// echo "<pre>" . var_dump($_SESSION) . "</pre>";
if (!isset($_SESSION['login_id'])) {
    header('Location: login.php');
}
$query = "SELECT verified FROM userpass WHERE user_id = :userid";
$handler = $conn->prepare($query);
$handler -> execute([
    ":userid" => $_SESSION['login_id']
]);
$res =  $handler->fetchAll(PDO::FETCH_OBJ);

if (isset($res[0]->verified)) {
    $verstatus = $res[0]->verified;
}
// echo "<pre>" . var_dump($res) . "</pre>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'links.php'; ?>
    <title>Personal Blog</title>
    <?php include 'js&css/colorschemes.php'; ?>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <?php include 'functionbar.php';?>
    <?php include 'posts-mypost.php';?>
    <?php if (isset($verstatus) && $verstatus == 1) {include 'make-a-post-bar.php';}?>
</body>
</html>
