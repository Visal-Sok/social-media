<?php

include("connect.php");

?>

<?php

$handlercheckemailerrormsg = "";
$handlercheckunameerrormsg = "";

if (isset($_POST['password']) && $_POST['confirmpassword']) {
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    if ($password == $confirmpassword) {
        $confirmedpassword = hash('sha256', $password);
    }
}

// function generateRandomToken($length) {
//     $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
//     $randomString = '';
//     for ($i = 0; $i < $length; $i++) {
//         $randomString .= $characters[rand(0, strlen($characters) - 1)];
//     }
//     return $randomString;
// }

if (isset($_POST['email']) && $_POST['username'] && isset($confirmedpassword)) {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $checkemailquery = "SELECT user_email FROM userpass WHERE user_email = :email";
    $handlercheckemail = $conn->prepare($checkemailquery);
    $handlercheckemail -> execute([
        ":email" => $email
    ]);
    $checkunamequery = "SELECT user_name FROM userpass WHERE user_name = :username";
    $handlercheckuname = $conn->prepare($checkunamequery);
    $handlercheckuname -> execute([
        ":username" => $username
    ]);
    if ($handlercheckemail -> rowCount() == 1) {
        $handlercheckunameerrormsg = "This username is already in use!";
    }
    if ($handlercheckuname -> rowCount() == 1) {
        $handlercheckemailerrormsg = "This email is already in use!";
    }
    if ($handlercheckemail -> rowCount() == 0 && $handlercheckuname -> rowCount() == 0) {
        $query = "INSERT INTO userpass (user_email, user_name, user_password, user_role) VALUES (:email, :username, :upassword, 'Guest')";
        $handlerinsert = $conn->prepare($query);
        $handlerinsert -> execute([
            ":email" => $email,
            ":username" => $username,
            ":upassword" => $confirmedpassword
        ]);
        $_SESSION['registered'] = 1;
        header('Location: login.php');
    }
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Account</title>
    <link rel="stylesheet" href="js&css/stylelogin.css">
    <link rel="stylesheet" href="js&css\colorschemelogin.css" preload="true">
</head>
<body>
    <div class="backgroundgradient">
        <div class="form1">
            <form method="POST">
                <h1><center>Sign Up to your Nickverse Account</center></h1><br>
                <div class="errormsg">
                    <?php
                        echo $handlercheckunameerrormsg;
                        echo $handlercheckemailerrormsg;
                    ?>
                </div>

                <br>
                <!-- Email -->
                <div class="inputtext">
                    <label>Email: </label>
                    <input type="text" name="email" placeholder="  E-mail" autocomplete="off"></input>
                </div>

                </br>
                <!-- Username -->
                <div class="inputtext">
                    <label>Username: </label>
                    <input type="text" name="username" placeholder="  Username" autocomplete="off"></input>
                </div>

                </br>
                <!-- Password -->
                <div class="inputtext">
                    <label>Password:</label>
                    <input type="password" name="password" type="password" placeholder="  8 - 36 Characters" autocomplete="off"></input>
                </div>
                <br>
                <!-- Confirm Password -->
                <div class="inputtext">
                    <label>Confirm Password:</label>
                    <input type="password" name="confirmpassword" type="password" placeholder="  8 - 36 Characters" autocomplete="off"></input>
                </div>
                <br>
                <br>
                <br>

                <button type="submit" class='loginbtn'>Sign Up</button>
            </form>
            <?php  ?>
                <!-- <div class="verifytitle">
                    A verification code has been sent to your email address
                </div> -->
                <!-- <form> -->
                    <!-- <div class="verifysection">
                        <label>Verification Code:</label></br>
                    </div>
                    <div class="verifysection2">
                        <input type="text" name="verifycode" placeholder="Verification Code" autocomplete="off"></input>
                    </div>
                    <button type="submit" class='loginbtn'>Submit</button> -->
                    <style>
                        .form1 {
                            flex-direction: column;
                            align-items: center;
                        }
                        input[type="text"] {
                            width: 60% !important;
                        }
                        .verifysection {
                            width: 30%;
                            display: flex;
                            height: 30%;
                            flex-shrink: 0;
                            align-items: center;
                            text-align: center;
                            position: absolute;
                            top: 260px;
                            flex-direction: row;
                        }
                        .verifysection2 {
                            width: 30%;
                            display: flex;
                            height: 30%;
                            text-align: center;
                            flex-shrink: 0;
                            align-items: center;
                            top: 310px;
                            position: absolute;
                            flex-direction: row;
                        }
                        .verifytitle {
                            width: 100%;
                            height: 30%;
                            display: flex;
                            position: relative;
                            flex-shrink: 0;
                            top: 0;
                            font-size: 1.6rem;
                            top: -30px;
                            justify-content: center;
                            align-items: center;
                        }
                        .loginbtn{
                            /* position: relative !important;
                            top: 250px; */
                        }
                    </style>
                <!-- </form> -->
            <?php  ?>
        </div>
    </div>
    <style>
        
        .loginbtn{
            text-decoration: none;
            color: white;
            background-color: var(--darkestgreen);
            width: 165px;
            right: -410px;
            padding: 24px 36px 24px 36px;
            border-radius: 15px;
        }
    </style>
</body>
</html>
<?php

?>

<!--  value="if (isset ($_COOKIE['userpass'])) { echo $_COOKIE['userpass']; } ?>" -->
<!-- value="if (isset ($_COOKIE['userlogin'])) { echo $_COOKIE['userlogin']; } ?>" -->
<!--  value="if (isset ($_COOKIE['userrmbme'])) { echo $_COOKIE['userrmbme']; } ?>" -->