<?php
$query = "SELECT * FROM categories";
$handler = $conn->prepare($query);
$handler->execute();
$result = $handler->fetchAll(PDO::FETCH_OBJ);

function redirect($url) {
    echo "<script>window.location.href = '/social_media/{$url}';</script>";
    exit();
}


if (isset($_POST['category']) && isset($_POST['content']) && strlen($_POST['content']) >= 1) {
    $query = "INSERT INTO `userspost` (`user_id`, `post_content`, `post_date`, `post_category`) VALUES (:user_id, :post_content, :post_date, :post_category)";
    $handler = $conn->prepare($query);
    $handler -> execute([
        ":user_id" => $_SESSION['login_id'],
        ":post_content" => $_POST['content'],
        ":post_date" => date('Y-m-d H:i:s'),
        ":post_category" => $_POST['category']
    ]);
    redirect('index.php');
}

?>

<div class="advertisements fixed-top">
    <span class="make-a-post">Create a new post</span>
    <div class="make-a-post-form">
        <form method="post">
                <div class="cate-selector">
                    <label>Select A Category:</label>
                    <select id="category" name="category">
                        <option value="default">Choose a Category</option>
                        <?php foreach ($result as $category){
                            echo "<option value='$category->cat_name'>$category->cat_name</option>";
                        // <option value="Misc">Miscellaneous</option>
                        }
                        ?>
                    </select>
                    <input type="hidden" name="hiddenvalue" value="1"></input>
                </div><br>
                <div class="posting-content">
                    <label class="writeapost">Write Your Post! (550 Characters) </label>
                    <textarea name="content" id="content" rows="5" placeholder="Post"></textarea>
                </div>
                <div class="buttondiv">
                    <button type="submit" value="posted" class="make-a-post-submit">Post</button>
                </div>
        </form>
    </div>
</div>
<style>
.make-a-post {
    font-weight: bold !important;
    display: flex;
    font-family: 'Montserrat', sans-serif;
    padding: 40px 0px 25px 0px;
    font-size: 2.4rem;
    text-align: center;
    justify-content: center;
}
.make-a-post-form {
    display: flex;
    flex-direction: column;
    padding-left: 20px !important;
    padding-right: 20px !important;
    justify-content: space-between;
    flex-shrink: 0;
    height: 100%;
}
.cate-selector {
    align-items: center;
    display: flex;
    flex-shrink: 0;
    width: 100%;
    justify-content: space-between;
    height: 6%;
}
.make-a-post-form form {
    height: 90%;
}
.writeapost {
    padding-bottom: 20px;
}
.posting-content {
    font-family: 'Montserrat', sans-serif;
    font-size: 1.2rem;
    font-weight: bold;
}
/* .make-a-post-form div {
    justify-content: space-around;
    width: 100%;
    height: 15%;
} */
.make-a-post-form select {
    width: 60%;
    height: 35px;
}
form textarea {
    width: 100%;
    height: 48vh;
    resize: none;
    border: none;
    border-radius: 10px;
    padding: 10px;
}
.make-a-post-submit {
    margin-top: 24px;
    width: 120px;
    height: 48px;
    font-size: 1.2rem;
    font-weight: bold;
    text-align: center;
    background-color: var(--darkgreen);
    right: 0;
    border: 0px solid;
    border-radius: 24px;
    color: var(--greenishwhite);
}
.buttondiv {
    display: flex;
    justify-content: end;
}
</style>
<script>
  const category = document.getElementById('category');
  const submitButton = document.getElementById('make-a-post-submit');

  submitButton.disabled = true;
  category.addEventListener('change', () => {
    if (category.value === 'default') {
      submitButton.disabled = true;
    } else {
      submitButton.disabled = false;
    }
  });
</script>