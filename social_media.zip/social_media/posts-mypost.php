<?php

$query = "SELECT upass.*, post.* 
            FROM `userspost` post 
            INNER JOIN `userpass` upass 
            ON post.user_id = upass.user_id 
            WHERE upass.user_id = :user_id
            ORDER BY post.post_date DESC ";
$handler = $conn -> prepare($query);
$handler -> execute([
    ':user_id' => $_SESSION['login_id']
]);
$result = $handler->fetchAll(PDO::FETCH_OBJ);

// echo "<pre>" . var_dump($result) . "</pre>";
// echo count($result);
$countrow = count($result);?>
<?php if($countrow>0){
    echo "<div class='containing'>";
    foreach ($result as $post) {
        $postngm = $post->post_engagements;
        $post_date = date('Y-m-d, h:ia', strtotime($post->post_date));
        if (!isset($post->user_pfp)) {
            $pfpprofile = " <span class='material-symbols-outlined myicon'>
                                account_circle
                            </span>";
        } else {
            $profilepath = $post->user_pfp;
            if (is_null($post->user_pfp)) {
                $pfpprofile = " <span class='material-symbols-outlined myicon'>
                                    account_circle
                                </span>";
            }else {
                $pfpprofile = "<img src='$profilepath' class='profile-pic2'>";
            }
        }
        echo "<div class='posts'>
                <div class='profile-container'>
                    $pfpprofile
                </div>
                <div class='post-container'>
                    <div class='user-info'>
                        <span class='usersname'>$post->user_name </span> &nbsp; &nbsp;&#x2022; &nbsp;&nbsp;$post->user_role
                    </div>
                    <div class='content'>
                        <span class='postcat'>$post->post_category</span><br><br>
                        <span class='post_content'>$post->post_content</span>
                        <span class='post_date'>$post_date</span>
                    </div>
                    <div class='actions'>
                        <div class='ngminfo'>
                            <span class='material-symbols-outlined heart-icon'>
                                monitoring
                            </span> &nbsp;
                            <span class='likengm'>
                                $postngm
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <hr>";
    }
    echo "</div>";
}else {
    echo "<div class='containing'><span class='nopostyet'>You Have Not Posted Anything Yet!<br><br>Be Brave! Make your first post!</span></div>";
    
    echo "  <style>
                .containing {
                    background-color: transparent !important;
                    border: none !important;
                    box-shadow: none !important;
                }
            </style>";
}
echo "  <style>
            .containing {
                height: calc(($countrow*50vh)+50px);
            }
            .myicon {
                color: white;
            }
        </style>";

        // <span class='post_date'>$post->post_date</span>


?>